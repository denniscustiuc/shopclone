

export default function FourOhFour(){
    return (
        <div>The page you are looking for does not exist</div>
    );
}